<?php
	require('config.php');

	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}
	
	if (!isset($_SESSION['logged_in']) 
		|| $_SESSION['logged_in'] !== true) {
		header('Location: login.php');
		exit;
	}

	$username = $_SESSION['username'];
	
	$db = new mysqli($mysql_host, $mysql_user, $mysql_password) or die(__LINE__ . ' Invalid connect: ' . mysqli_error());
	$db->select_db($mysql_database) or die( "Unable to select database. Run setup first.");
	
	$stmt = $db->prepare("DELETE FROM logs");
	
	$success = $stmt->execute();
	$stmt = $db->prepare("DELETE FROM passwords");
	
	$success = $stmt->execute();
	$stmt = $db->prepare("DELETE FROM screens");
	
	$success = $stmt->execute();
	$stmt = $db->prepare("DELETE FROM webcam");
	
	$success = $stmt->execute();
	$stmt = $db->prepare("DELETE FROM cookies");
	
	$success = $stmt->execute();
	header('Location:index.php');
	exit;

?>