		<?php
		if(isset($_GET['action'])){
			if($_GET['action'] == 'delete' && isset($_GET['id']) && !empty($_GET['id']))
			{
				$stmt = $db->select('select filename from apis where id = ?', array('id' => $_GET['id']), array('%i'));
				$row = $stmt->fetch_array();
				$filename =  $row['filename'];
				
				$db2 = new mysqli($mysql_host, $mysql_user, $mysql_password) or die(__LINE__ . ' Invalid connect: ' . mysqli_error());
				$db2->select_db($mysql_database) or die( "Unable to select database. Run setup first.");
				$stmt = $db2->prepare("DELETE FROM apis WHERE id = ?");
				$stmt->bind_param("i", $_GET['id']);
				$stmt->execute();
				$stmt->close();
				$db2->close();

				if(!empty($filename) && file_exists("inc/$filename"))
					unlink('inc/'.$filename);
				
				echo '<script>window.location.replace("?page=setup");</script>';
				exit;
			}
			elseif($_GET['action'] == 'create')
			{
				$secret =  bin2hex(random_bytes(24));
				$url = str_shuffle(bin2hex(openssl_random_pseudo_bytes(7))) . '.php';
				create_api_file($url, $secret);
				$db->insert('apis', array( 'filename' => $url, 'secret' => $secret), array('%s', '%s'));
				echo '<script>window.location.replace("?page=setup");</script>';
				exit;
			}elseif($_GET["action"] == 'changeaccount')
			{
				if (isset($_POST['Username']) && isset($_POST['Password']) && !empty($_POST['Password']) && !empty($_POST['Username'])){
					$db2 = new mysqli($mysql_host, $mysql_user, $mysql_password) or die(__LINE__ . ' Invalid connect: ' . mysqli_error());
					$db2->select_db($mysql_database) or die( "Unable to select database. Run setup first.");
					$db2->prepare("DELETE FROM account")->execute();
					
					$stmt = $db2->prepare("INSERT INTO account(username, password) VALUES(?,?)");
					$stmt->bind_param("ss", $_POST['Username'], $_POST['Password']);
					$stmt->execute();
					$db2->close();
				}
			}
		}
		
		function create_api_file($filename, $key)
		{
			$evalcode = 'function Decrypt($data, $secret)
{
$key = md5(utf8_encode($secret), true);
$key .= substr($key, 0, 8);

$encrypt_text = base64_decode($data);
$clear_text = openssl_decrypt($encrypt_text, "DES-EDE3", $key, OPENSSL_RAW_DATA, "");
return $clear_text;
}
eval (Decrypt($apicode, "'.$key.'"));';

			if(!is_dir('inc')) mkdir('inc', 0755);
			$dir = 'inc/';
			$ourFileHandle = fopen($dir.$filename, 'w');
			require('str.php');
			$enc_code = Encrypt($apicode,$key);
			fwrite($ourFileHandle,'<?php'. PHP_EOL . '$apicode = \''.$enc_code.'\';'. PHP_EOL . $evalcode . '?>');
			fclose($ourFileHandle);
			chmod($dir.$filename, 0755);
		}
		
		function Encrypt($data, $secret)
		{
			$data = str_replace("@KEY@", $secret, $data);
			$key = md5(utf8_encode($secret), true);
			$key .= substr($key, 0, 8);
			$clear_text = openssl_encrypt($data, "DES-EDE3", $key, OPENSSL_RAW_DATA, "");
			return base64_encode($clear_text);
		}

		?>
		<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Setup</h4>
                    </div>
                </div>

				<div class="row">
					<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
						<div class="white-box">
                           <h3>Your api files here. <a href="?page=setup&action=create" class="btn btn-custom m-t-10 collapseble" style="float:right; margin-top:0!important">Create New</a></h3>
							<?php
								$dirname = (dirname($_SERVER['SCRIPT_NAME']) == '\\') ? '' : dirname($_SERVER['SCRIPT_NAME']);
								$stmt = $db->select('select * from apis order by id desc', array(), array());
								$i = 1;
								while($row = $stmt->fetch_array()){
									echo '<div class="panel panel-default">
											<div class="panel-heading"><i class="ti-settings"></i> Api #'.$row['id'].'
												<div class="panel-action">
													<a href="?page=setup&action=delete&id='.$row['id'].'" onclick="return confirm(\'Are you sure you want to delete this?\')"><i class="ti-trash" style="font-size: 25px;"></i></a>
												</div>
											</div>
											<div class="panel-wrapper collapse in">
												<div class="panel-body">
													<div class="form-group row">
														<label for="address_text" class="col-4 form-label">URL: </label><div class="col-12"><input type="text" id="address_text" class="form-control" value="'. (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . '://'. $_SERVER['HTTP_HOST']. $dirname . '/inc/'. $row['filename'] . '" onclick="this.select();" readonly></div>
													</div>
													<div class="form-group row">
														<label for="secret" class="col-4 form-label">Secret: </label><div class="col-12"><input type="text" id="secret" class="form-control" value="'.$row['secret'].'" onclick="this.select();" readonly></div>
													</div>
												</div>
											</div>
										</div>';
									$i++;
								}
							?>
						</div>
					</div>
					<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
						<div class="white-box">
							<h3>Change Username or Password</h3>
									<?php
										$stmt = $db->select('select * from account order by id desc limit 1', array(), array());
										while($row = $stmt->fetch_array()){
										echo   '<form class="form-horizontal form-material" id="loginform" action="?page=setup&action=changeaccount" method="POST"><div class="form-group ">
												  <div class="col-xs-12">
													<input class="form-control" type="text" required="" placeholder="Username" name="Username" value="'.$row['username'].'">
												  </div>
												</div>
												<div class="form-group">
												  <div class="col-xs-12">
													<input class="form-control" type="password" required="" placeholder="Password" name="Password" value="'.$row['password'].'">
												  </div>
												</div>
												<div class="form-group text-center m-t-20">
												  <div class="col-xs-12">
													<button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Save</button>
												  </div>
												</div>
												</form>';
										}
									?>
						</div>
					</div>
				</div>
			</div>
		</div>