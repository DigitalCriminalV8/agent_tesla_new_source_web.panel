		<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Screenshots</h4>
                    </div>
                </div>

				<div class="row">
					<div class="col-md-12 col-lg-12 col-sm-12">
						<div class="white-box">
							<h3 class="box-title m-b-0">Screenshots</h3>
                            <p class="text-muted m-b-30">Here you can view and delete screenshots of computers.</p>
							<div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover dataTables-Screenshots" cellspacing="0" width="100%">
									 <?php
									echo '
									<thead>
									<tr>
									';
									echo '

									<th>Server Time</th>
									<th>HWID</th>
									<th>Machine Name</th>
									<th>Action</th>
									</tr>
									</thead>
									<tbody>
									';
									$stmt = $db->select('SELECT * FROM screens t JOIN (SELECT hwid AS hwidOf, MAX(server_time) AS DateOf FROM screens GROUP BY hwid) t2 ON (t.hwid = t2.hwidOf AND t.server_time = t2.DateOf) ORDER BY t.server_time DESC', array(), array());
									
									while($row = $stmt->fetch_array()){
										echo "<tr>";
										echo "<td>" . $row['server_time'] . "</td>";
										echo "<td>" . $row['hwid'] . "</td>";
										echo "<td>" . $row['pc_name'] . "</td>";
										echo '<td><a href=?page=get-screen&id=' . $row["hwid"] . '&title='.$row['pc_name'].' class="btn btn-outline btn-primary btn-sm">View</a> | <a href=delete.php?type=screen&id=' . $row["hwid"] .
											' class="btn btn-outline btn-danger btn-sm" onclick="return confirm(\'Are you sure you want to delete this?\')">Delete</a></td>';
										echo "</tr>";
									}
								 
									echo '
									</tbody>
									';

									?>		
                                </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	<script>
		$(document).ready(function() {
			$('.dataTables-Screenshots').dataTable({
				"order": [[ 0, "desc" ]]
            });
		});
    </script>