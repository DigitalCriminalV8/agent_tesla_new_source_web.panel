<?php
	session_start();
	
	$errorMessage = "";
	header('Content-Type: text/html; charset=utf-8');
	if(!file_exists('config.php'))
		header('Location: setup.php');
	if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
	   header('Location: index.php');
	}
	require_once('config.php');
	if (isset($_POST['Username']) && isset($_POST['Password'])){
		$log_username = $_POST['Username'];
		$log_password = $_POST['Password'];
		
		if($log_username == $username && $log_password == $password){
			$_SESSION['logged_in'] = true;
			
			require("create.php");
			header('Location: index.php');
		}else{
			$errorMessage="Wrong username/password.";
		}		
	}
?>

<html>

<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
    <title>Login</title>
	
	<!-- Bootstrap Core CSS -->
	<link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css" rel="stylesheet">  
	<link rel="stylesheet" type="text/css" href="plugins/sweetalert/dist/sweetalert.css">
	<script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>

	<style>
		body{max-width: 500px; margin: auto;margin-top:100px;}
	</style>
</head>

<body>
<section id="wrapper">
  <div class="login-box">
    <div class="white-box">
		<?php if(!empty($errorMessage)){echo '<script type="text/javascript">$(function(){sweetAlert("Oops...", "'.$errorMessage.'", "error");})</script>';}?>
      <form class="form-horizontal form-material" id="loginform" action="login.php" method="POST">
        <h3 class="box-title m-b-20">Sign In</h3>
        <div class="form-group ">
          <div class="col-xs-12">
            <input class="form-control" type="text" required="" placeholder="Username" name="Username">
          </div>
        </div>
        <div class="form-group">
          <div class="col-xs-12">
            <input class="form-control" type="password" required="" placeholder="Password" name="Password">
          </div>
        </div>
        <div class="form-group text-center m-t-20">
          <div class="col-xs-12">
            <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Log In</button>
          </div>
        </div>
      </form>

    </div>
  </div>
</section>

<script src="bootstrap/dist/js/tether.min.js"></script>
<script src="bootstrap/dist/js/bootstrap.min.js"></script>
<script src="plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
<script src="plugins/sweetalert/dist/sweetalert.min.js"></script>
</body>
</html>
